#!/bin/bash
isrunning=`pgrep -u root,$(whoami) firefox | wc -l`
if [ $isrunning -ne 0 ]; then
	killall -r firefox
fi

certificateFile="/opt/interezen/ipinside/interezen.crt";
certificateName="Interezen CA";

# Firfox Setting ------------------------------------------------------------------------------------------
ROOTFIRFOX=/root/.mozilla/firefox

for certDB in $(find $ROOTFIRFOX_home -name "cert8.db")
do
	certDir=$(dirname ${certDB});
	certutil -A -n "${certificateName}" -t "TCu,Cuw,Tuw" -i ${certificateFile} -d ${certDir};
done

for entry in "/home"/*
do
	USERFIRFOX="$entry"/.mozilla/firefox

	for certDB in $(find $USERFIRFOX -name "cert8.db")
	do
		certDir=$(dirname ${certDB});
		certutil -A -n "${certificateName}" -t "TCu,Cuw,Tuw" -i ${certificateFile} -d ${certDir};
	done
done
# ---------------------------------------------------------------------------------------------------------

# Chrome Setting ------------------------------------------------------------------------------------------
for chromehome in "/home"/*
do
	chromeuser="$chromehome"/.pki/nssdb

	echo $chromeuser

	for certDB in $(find $chromeuser -name "cert9.db")
	do
		certDir=$(dirname ${certDB});

		echo $certDir
		certutil -A -n "${certificateName}" -t "CP,CP," -i ${certificateFile} -d sql:${certDir};
	done
done
# ---------------------------------------------------------------------------------------------------------

Version=$(lsb_release -r --short) | cut -d'.' -f1

if [[ ( $((Version+0)) > 15 ) || ( ( $((Version+0)) == 15 ) ) ]] ; then
	AUTOSTARTUSERDIR=/etc/xdg/
	
	cp /usr/share/applications/IPinside-LWS.desktop $AUTOSTARTUSERDIR
else
	for entry in "/home"/*
	do
		AUTOSTARTUSERDIR="$entry"/.config/autostart

		if [ -d $AUTOSTARTUSERDIR ];then
			cp /usr/share/applications/IPinside-LWS.desktop $AUTOSTARTUSERDIR
		else
			mkdir $AUTOSTARTUSERDIR
			cp /usr/share/applications/IPinside-LWS.desktop $AUTOSTARTUSERDIR
		fi
	done

	AUTOSTARTROOTDIR=/root/.config/autostart

	if [ -d $AUTOSTARTROOTDIR ];then
		cp /usr/share/applications/IPinside-LWS.desktop $AUTOSTARTROOTDIR
	else
		mkdir $AUTOSTARTROOTDIR
		cp /usr/share/applications/IPinside-LWS.desktop $AUTOSTARTROOTDIR
	fi
fi

chmod 755 /etc/init.d/LWS-IPinsided;
	
sysv-rc-conf LWS-IPinsided on;
 
#/etc/init.d/LWS-IPinsided start
nohup /etc/init.d/LWS-IPinsided start 0<&- &>/dev/null &

exit 0
